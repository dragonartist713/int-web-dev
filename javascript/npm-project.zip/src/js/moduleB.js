function doSomething(){
    console.log("doing something else");
}

export{doSomething}