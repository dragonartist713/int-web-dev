
alert("Add code to main.js to assemble the parts to make the Employee app")
