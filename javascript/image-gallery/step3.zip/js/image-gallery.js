
const createGallery = (el, images) => {
	

}